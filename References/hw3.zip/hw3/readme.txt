STATEMENT:

Efrat Hazani  200890317
Nirit Lapidot 201143518

This work is ours, we did not include code from other class members, or code found online.